Instruction for installation:

1. Unzip all files under a particular folder X. For example, X can be "My Documents\Matlab Toolboxes".
2. Open Matlab, and change its current directory to X.
3. Run in Matlab the command "install". Basically, this function addes all required folder to Matlab's search path.